
-- !! step final: re-index search tables + clear out any concept counts that may have been generated

use LeafDB

update app.concept set UiDisplayPatientCount = null;
update app.concept set UiDisplayPatientCountByYear = null;
update app.concept set ispatientcountautocalculated = 0;
update app.concept set PatientCountLastUpdateDateTime = null;

update leafdb.app.concept set AddDateTime = getdate()
update leafdb.app.concept set ContentLastUpdateDateTime = getdate()

delete from [LeafDB].[app].[ConceptForwardIndex]
delete from [LeafDB].[app].[ConceptInvertedIndex]
delete from [LeafDB].[app].[ConceptTokenizedIndex]

EXEC app.sp_UpdateSearchIndexTables;
